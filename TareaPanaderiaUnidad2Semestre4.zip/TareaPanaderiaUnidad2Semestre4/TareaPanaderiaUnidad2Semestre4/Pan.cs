﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TareaPanaderiaUnidad2Semestre4;

namespace TareaPanaderiaUnidad2Semestre4
{
    public class Pan
    {
        public string Nombre { get; set; } = null!;
        public decimal Precio { get; set; }
        public ushort CantidadDisponible { get; set; }

    }
}
