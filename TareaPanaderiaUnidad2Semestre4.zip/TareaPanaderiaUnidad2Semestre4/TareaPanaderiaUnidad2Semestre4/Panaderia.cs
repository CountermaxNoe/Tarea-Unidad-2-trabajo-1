﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TareaPanaderiaUnidad2Semestre4
{
    public class Panaderia : INotifyPropertyChanged
    {
        public ObservableCollection<Pan> panes { get; set; } = new();
        public ICommand VenderCommmand {  get; set; }
        public ICommand EliminarCommand { get; set; }
        public Pan OrdenenEliminar {  get; set; }=new();
        public Panaderia() 
        {
            EliminarCommand = new RelayCommand(Eliminar);
            VenderCommmand = new RelayCommand<Pan>(Vender);
        }

        public void Vender(Pan Orden)
        {
            if (Orden != null)
            {
                var clon = new Pan
                {
                    Nombre = Orden.Nombre,
                    CantidadDisponible = Orden.CantidadDisponible,
                    Precio = Orden.Precio,
                };
                panes.Add(clon);
            }
        }
        public void Eliminar()
        {
            if (OrdenenEliminar != null)
            {
                panes.Remove(OrdenenEliminar);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
