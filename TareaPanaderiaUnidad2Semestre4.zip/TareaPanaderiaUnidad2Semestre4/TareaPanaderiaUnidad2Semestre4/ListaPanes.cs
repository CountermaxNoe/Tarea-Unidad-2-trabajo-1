﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TareaPanaderiaUnidad2Semestre4;

namespace TareaPanaderiaUnidad2Semestre4
{
    public class ListaPanes
    {
        List<Pan> panes = new List<Pan>() 
        {
            new Pan { Nombre = "Bolillo", Precio = 6m, CantidadDisponible = 100 },
            new Pan { Nombre = "Cuernito", Precio = 6m, CantidadDisponible = 100 },
            new Pan { Nombre = "Concha", Precio = 6m, CantidadDisponible = 100 },
            new Pan { Nombre = "Dona", Precio = 6m, CantidadDisponible = 100 },
            new Pan { Nombre = "Baguette", Precio = 6m, CantidadDisponible = 100 },
            new Pan { Nombre = "Galleta", Precio = 6m, CantidadDisponible = 100 },
        };
    }
}
